import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    accessToken: ''
}
export const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers:{
        setAcccessToken : (state, action) =>{
            state.accessToken = action.payload;
        },
        setLogout: (state) =>{
            state.accessToken= null;
        }
    }
})
export const {setAcccessToken, setLogout} = authSlice.actions;
export default authSlice.reducer;